package com.example.apptemplatebottomnav3

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    var prevMenuItem: MenuItem? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // initializing viewPager2
        val viewPager2 = findViewById<View>(R.id.fragmentContainer) as ViewPager2


        // initializing the bottomNavigationView
        val bottomNavigationView = findViewById<View>(R.id.bottomBar) as BottomNavigationView
        bottomNavigationView.setOnItemSelectedListener { item ->
            val id = item.itemId
            if (id == R.id.navigation_first) {
                viewPager2.currentItem = 0
            }
            if (id == R.id.navigation_second) {
                viewPager2.currentItem = 1
            }
            if (id == R.id.navigation_third) {
                viewPager2.currentItem = 2

            } else if (id == R.id.navigation_fourth) {
                viewPager2.currentItem = 3
            }
            true
        }


        // track active fragment
        viewPager2.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                if (prevMenuItem != null) {
                    prevMenuItem!!.setChecked(false)
                } else {
                    bottomNavigationView.menu.getItem(0).setChecked(false)
                }
//                Log.d("page", "" + position)
                bottomNavigationView.menu.getItem(position).setChecked(true)
                prevMenuItem = bottomNavigationView.menu.getItem(position)
            }

        })


        // fragments swipe stuff
        val fragmentList = arrayListOf(
            FirstFragment.newInstance(),
            SecondFragment.newInstance(),
            ThirdFragment.newInstance(),
            FourthFragment.newInstance()
        )
        viewPager2.adapter = ViewPagerAdapter(this, fragmentList)
    }


    class ViewPagerAdapter(fa: FragmentActivity, private val fragments:ArrayList<Fragment>): FragmentStateAdapter(fa) {

        override fun getItemCount(): Int = fragments.size

        override fun createFragment(position: Int): Fragment = fragments[position]
    }


    // top menu stuff
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.top_nav_menu, menu)
        return true
    }


    // open dialogs on top menu item click
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {


            R.id.item_1 -> {

                MaterialAlertDialogBuilder(this, R.style.MaterialAlertDialog_rounded)
                    .setTitle("Help")
                    .setMessage("This is a help dialogue")
                    .setPositiveButton("OK", null)
                    .setCancelable(true)
                    .create()
                    .apply {
                        setCanceledOnTouchOutside(true)
                        show()
                    }
            }


            R.id.item_2 -> {

                MaterialAlertDialogBuilder(this, R.style.MaterialAlertDialog_rounded)
                    .setTitle("About")
                    .setMessage("This is an about dialogue")
                    .setPositiveButton("OK", null)
                    .setCancelable(true)
                    .create()
                    .apply {
                        setCanceledOnTouchOutside(true)
                        show()
                    }
            }


            R.id.item_3 -> {

                val loremIpsum = "This is a settings dialogue"

                MaterialAlertDialogBuilder(this, R.style.MaterialAlertDialog_rounded)
                    .setTitle("Settings")
                    .setMessage(loremIpsum)
                    .setPositiveButton("OK") { _, _ ->
                        // do something
                        Toast.makeText(this, "Settings Menu Closed", Toast.LENGTH_SHORT).show()
                    }
                    .setCancelable(true)
                    .create()
                    .apply {
                        setCanceledOnTouchOutside(true)
                        show()
                    }
            }

        }

        return super.onOptionsItemSelected(item)
    }

}