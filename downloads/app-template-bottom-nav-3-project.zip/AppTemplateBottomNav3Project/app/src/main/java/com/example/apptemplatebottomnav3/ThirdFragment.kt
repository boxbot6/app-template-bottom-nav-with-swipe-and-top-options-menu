package com.example.apptemplatebottomnav3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver.OnGlobalLayoutListener
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class ThirdFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view: View = inflater.inflate(R.layout.fragment_third, container, false)


        // measures the height of the original parent view and uses it in the scrollview layout3 to match the other fragments
        val parent = view.findViewById(R.id.masterHeight) as RelativeLayout
        parent.viewTreeObserver.addOnGlobalLayoutListener(object : OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                //val availableWidth = parent.measuredWidth
                val availableHeight = parent.measuredHeight
                if (availableHeight > 0) {
                    parent.viewTreeObserver.removeOnGlobalLayoutListener(this)

                    // use height here and do whatever you want with it
                    val screenScale3 = view.findViewById<View>(R.id.layout3) as LinearLayout
                    val params = screenScale3.layoutParams as LinearLayout.LayoutParams
                    params.apply {
                        //width = availableWidth
                        height = availableHeight

                        screenScale3.layoutParams = params
                        //Toast.makeText(getActivity(), "Master Height = $availableHeight", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })


        // buttons
        val button1 = view.findViewById<View>(R.id.button1) as Button
        button1.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 1 Pressed", Toast.LENGTH_SHORT).show()
        }

        val button2 = view.findViewById<View>(R.id.button2) as Button
        button2.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 2 Pressed", Toast.LENGTH_SHORT).show()
        }

        val button3 = view.findViewById<View>(R.id.button3) as Button
        button3.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 3 Pressed", Toast.LENGTH_SHORT).show()
        }

        val button4 = view.findViewById<View>(R.id.button4) as Button
        button4.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 4 Pressed", Toast.LENGTH_SHORT).show()
        }

        val button5 = view.findViewById<View>(R.id.button5) as Button
        button5.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 5 Pressed", Toast.LENGTH_SHORT).show()
        }

        val button6 = view.findViewById<View>(R.id.button6) as Button
        button6.setOnClickListener {
            // place your action here
            Toast.makeText(this.requireActivity(), "Button 6 Pressed", Toast.LENGTH_SHORT).show()
        }

        // scrolls back to top when pressed
        val scroll = view.findViewById(R.id.myScrollView) as ScrollView
        val button7 = view.findViewById<View>(R.id.button7) as TextView
        button7.setOnClickListener {
            // place your action here
            scroll.smoothScrollTo(0,0)
        }


        return view
    }


    companion object{
        fun newInstance() = ThirdFragment()
    }

    // set this fragments name in title bar
    override fun onResume() {
        super.onResume()
        (requireActivity() as MainActivity).supportActionBar?.title = "Third"
    }

}